test_that("run_app function exists", {
  expect_true(exists("run_app"))
})